﻿namespace Kadai1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.button0 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonAns = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSub = new System.Windows.Forms.Button();
            this.buttonMult = new System.Windows.Forms.Button();
            this.buttonDiv = new System.Windows.Forms.Button();
            this.numBox = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.終了ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tax10Box = new System.Windows.Forms.TextBox();
            this.tax8Box = new System.Windows.Forms.TextBox();
            this.tax10Button = new System.Windows.Forms.Button();
            this.tax8Button = new System.Windows.Forms.Button();
            this.taxType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.taxAnsBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.binBox = new System.Windows.Forms.TextBox();
            this.octBox = new System.Windows.Forms.TextBox();
            this.decBox = new System.Windows.Forms.TextBox();
            this.hexBox = new System.Windows.Forms.TextBox();
            this.mc = new System.Windows.Forms.Button();
            this.mr = new System.Windows.Forms.Button();
            this.mPlus = new System.Windows.Forms.Button();
            this.mMinus = new System.Windows.Forms.Button();
            this.ms = new System.Windows.Forms.Button();
            this.m = new System.Windows.Forms.Button();
            this.mAns = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(203, 331);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(75, 23);
            this.button0.TabIndex = 0;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(127, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(203, 302);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(285, 302);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(127, 273);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(203, 272);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(285, 272);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(127, 244);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(204, 244);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(284, 244);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonAns
            // 
            this.buttonAns.Location = new System.Drawing.Point(385, 340);
            this.buttonAns.Name = "buttonAns";
            this.buttonAns.Size = new System.Drawing.Size(75, 23);
            this.buttonAns.TabIndex = 10;
            this.buttonAns.Text = "=";
            this.buttonAns.UseVisualStyleBackColor = true;
            this.buttonAns.Click += new System.EventHandler(this.buttonAns_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(127, 195);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(75, 23);
            this.buttonClear.TabIndex = 11;
            this.buttonClear.Text = "C";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(385, 302);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 12;
            this.buttonAdd.Text = "+";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSub
            // 
            this.buttonSub.Location = new System.Drawing.Point(385, 272);
            this.buttonSub.Name = "buttonSub";
            this.buttonSub.Size = new System.Drawing.Size(75, 23);
            this.buttonSub.TabIndex = 13;
            this.buttonSub.Text = "-";
            this.buttonSub.UseVisualStyleBackColor = true;
            this.buttonSub.Click += new System.EventHandler(this.buttonSub_Click);
            // 
            // buttonMult
            // 
            this.buttonMult.Location = new System.Drawing.Point(385, 238);
            this.buttonMult.Name = "buttonMult";
            this.buttonMult.Size = new System.Drawing.Size(75, 23);
            this.buttonMult.TabIndex = 14;
            this.buttonMult.Text = "×";
            this.buttonMult.UseVisualStyleBackColor = true;
            this.buttonMult.Click += new System.EventHandler(this.buttonMult_Click);
            // 
            // buttonDiv
            // 
            this.buttonDiv.Location = new System.Drawing.Point(385, 195);
            this.buttonDiv.Name = "buttonDiv";
            this.buttonDiv.Size = new System.Drawing.Size(75, 23);
            this.buttonDiv.TabIndex = 15;
            this.buttonDiv.Text = "÷";
            this.buttonDiv.UseVisualStyleBackColor = true;
            this.buttonDiv.Click += new System.EventHandler(this.buttonDiv_Click);
            // 
            // numBox
            // 
            this.numBox.Enabled = false;
            this.numBox.Location = new System.Drawing.Point(209, 195);
            this.numBox.Name = "numBox";
            this.numBox.Size = new System.Drawing.Size(151, 19);
            this.numBox.TabIndex = 16;
            this.numBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numBox.TextChanged += new System.EventHandler(this.numBox_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.終了ToolStripMenuItem});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // 終了ToolStripMenuItem
            // 
            this.終了ToolStripMenuItem.Name = "終了ToolStripMenuItem";
            this.終了ToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.終了ToolStripMenuItem.Text = "終了";
            this.終了ToolStripMenuItem.Click += new System.EventHandler(this.終了ToolStripMenuItem_Click);
            // 
            // tax10Box
            // 
            this.tax10Box.Enabled = false;
            this.tax10Box.Location = new System.Drawing.Point(264, 131);
            this.tax10Box.Name = "tax10Box";
            this.tax10Box.Size = new System.Drawing.Size(100, 19);
            this.tax10Box.TabIndex = 19;
            this.tax10Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tax8Box
            // 
            this.tax8Box.Enabled = false;
            this.tax8Box.Location = new System.Drawing.Point(385, 131);
            this.tax8Box.Name = "tax8Box";
            this.tax8Box.Size = new System.Drawing.Size(100, 19);
            this.tax8Box.TabIndex = 20;
            this.tax8Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tax10Button
            // 
            this.tax10Button.Location = new System.Drawing.Point(264, 102);
            this.tax10Button.Name = "tax10Button";
            this.tax10Button.Size = new System.Drawing.Size(75, 23);
            this.tax10Button.TabIndex = 22;
            this.tax10Button.Text = "税込10％";
            this.tax10Button.UseVisualStyleBackColor = true;
            this.tax10Button.Click += new System.EventHandler(this.tax10Button_Click);
            // 
            // tax8Button
            // 
            this.tax8Button.Location = new System.Drawing.Point(385, 102);
            this.tax8Button.Name = "tax8Button";
            this.tax8Button.Size = new System.Drawing.Size(75, 23);
            this.tax8Button.TabIndex = 23;
            this.tax8Button.Text = "税込8％";
            this.tax8Button.UseVisualStyleBackColor = true;
            this.tax8Button.Click += new System.EventHandler(this.tax8Button_Click);
            // 
            // taxType
            // 
            this.taxType.FormattingEnabled = true;
            this.taxType.Items.AddRange(new object[] {
            "税込10％",
            "税込8％",
            "税抜10％",
            "税抜8％"});
            this.taxType.Location = new System.Drawing.Point(127, 105);
            this.taxType.Name = "taxType";
            this.taxType.Size = new System.Drawing.Size(131, 20);
            this.taxType.TabIndex = 24;
            this.taxType.Text = "税込税抜を選択";
            this.taxType.SelectedIndexChanged += new System.EventHandler(this.TaxTypeSelected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(127, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 12);
            this.label1.TabIndex = 25;
            this.label1.Text = "税率を選択";
            // 
            // taxAnsBox
            // 
            this.taxAnsBox.Enabled = false;
            this.taxAnsBox.Location = new System.Drawing.Point(127, 153);
            this.taxAnsBox.Name = "taxAnsBox";
            this.taxAnsBox.Size = new System.Drawing.Size(100, 19);
            this.taxAnsBox.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 382);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 12);
            this.label2.TabIndex = 27;
            this.label2.Text = "2進数binary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 382);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 12);
            this.label3.TabIndex = 28;
            this.label3.Text = "8進数octal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(426, 382);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 12);
            this.label4.TabIndex = 29;
            this.label4.Text = "16進数hexadecimal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(322, 382);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 12);
            this.label6.TabIndex = 31;
            this.label6.Text = "10進数decimal";
            // 
            // binBox
            // 
            this.binBox.Location = new System.Drawing.Point(112, 397);
            this.binBox.Name = "binBox";
            this.binBox.Size = new System.Drawing.Size(100, 19);
            this.binBox.TabIndex = 32;
            // 
            // octBox
            // 
            this.octBox.Location = new System.Drawing.Point(218, 397);
            this.octBox.Name = "octBox";
            this.octBox.Size = new System.Drawing.Size(100, 19);
            this.octBox.TabIndex = 33;
            // 
            // decBox
            // 
            this.decBox.Location = new System.Drawing.Point(324, 397);
            this.decBox.Name = "decBox";
            this.decBox.Size = new System.Drawing.Size(100, 19);
            this.decBox.TabIndex = 34;
            this.decBox.TextChanged += new System.EventHandler(this.decBox_TextChanged);
            // 
            // hexBox
            // 
            this.hexBox.Location = new System.Drawing.Point(430, 397);
            this.hexBox.Name = "hexBox";
            this.hexBox.Size = new System.Drawing.Size(100, 19);
            this.hexBox.TabIndex = 35;
            // 
            // mc
            // 
            this.mc.Location = new System.Drawing.Point(127, 28);
            this.mc.Name = "mc";
            this.mc.Size = new System.Drawing.Size(75, 23);
            this.mc.TabIndex = 36;
            this.mc.Text = "MC\r\n";
            this.mc.UseVisualStyleBackColor = true;
            this.mc.Click += new System.EventHandler(this.mc_Click);
            // 
            // mr
            // 
            this.mr.Location = new System.Drawing.Point(218, 27);
            this.mr.Name = "mr";
            this.mr.Size = new System.Drawing.Size(75, 23);
            this.mr.TabIndex = 37;
            this.mr.Text = "MR";
            this.mr.UseVisualStyleBackColor = true;
            this.mr.Click += new System.EventHandler(this.mr_Click);
            // 
            // mPlus
            // 
            this.mPlus.Location = new System.Drawing.Point(300, 27);
            this.mPlus.Name = "mPlus";
            this.mPlus.Size = new System.Drawing.Size(75, 23);
            this.mPlus.TabIndex = 38;
            this.mPlus.Text = "M+";
            this.mPlus.UseVisualStyleBackColor = true;
            this.mPlus.Click += new System.EventHandler(this.mPlus_Click);
            // 
            // mMinus
            // 
            this.mMinus.Location = new System.Drawing.Point(385, 27);
            this.mMinus.Name = "mMinus";
            this.mMinus.Size = new System.Drawing.Size(75, 23);
            this.mMinus.TabIndex = 39;
            this.mMinus.Text = "M-";
            this.mMinus.UseVisualStyleBackColor = true;
            this.mMinus.Click += new System.EventHandler(this.mMinus_Click);
            // 
            // ms
            // 
            this.ms.Location = new System.Drawing.Point(467, 26);
            this.ms.Name = "ms";
            this.ms.Size = new System.Drawing.Size(75, 23);
            this.ms.TabIndex = 40;
            this.ms.Text = "MS";
            this.ms.UseVisualStyleBackColor = true;
            this.ms.Click += new System.EventHandler(this.ms_Click);
            // 
            // m
            // 
            this.m.Location = new System.Drawing.Point(560, 26);
            this.m.Name = "m";
            this.m.Size = new System.Drawing.Size(75, 23);
            this.m.TabIndex = 41;
            this.m.Text = "M";
            this.m.UseVisualStyleBackColor = true;
            this.m.Click += new System.EventHandler(this.m_Click);
            // 
            // mAns
            // 
            this.mAns.Location = new System.Drawing.Point(560, 56);
            this.mAns.Name = "mAns";
            this.mAns.Size = new System.Drawing.Size(100, 19);
            this.mAns.TabIndex = 43;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mAns);
            this.Controls.Add(this.m);
            this.Controls.Add(this.ms);
            this.Controls.Add(this.mMinus);
            this.Controls.Add(this.mPlus);
            this.Controls.Add(this.mr);
            this.Controls.Add(this.mc);
            this.Controls.Add(this.hexBox);
            this.Controls.Add(this.decBox);
            this.Controls.Add(this.octBox);
            this.Controls.Add(this.binBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.taxAnsBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.taxType);
            this.Controls.Add(this.tax8Button);
            this.Controls.Add(this.tax10Button);
            this.Controls.Add(this.tax8Box);
            this.Controls.Add(this.tax10Box);
            this.Controls.Add(this.numBox);
            this.Controls.Add(this.buttonDiv);
            this.Controls.Add(this.buttonMult);
            this.Controls.Add(this.buttonSub);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonAns);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonAns;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonSub;
        private System.Windows.Forms.Button buttonMult;
        private System.Windows.Forms.Button buttonDiv;
        private System.Windows.Forms.TextBox numBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 終了ToolStripMenuItem;
        private System.Windows.Forms.TextBox tax10Box;
        private System.Windows.Forms.TextBox tax8Box;
        private System.Windows.Forms.Button tax10Button;
        private System.Windows.Forms.Button tax8Button;
        private System.Windows.Forms.ComboBox taxType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox taxAnsBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox binBox;
        private System.Windows.Forms.TextBox octBox;
        private System.Windows.Forms.TextBox decBox;
        private System.Windows.Forms.TextBox hexBox;
        private System.Windows.Forms.Button mc;
        private System.Windows.Forms.Button mr;
        private System.Windows.Forms.Button mPlus;
        private System.Windows.Forms.Button mMinus;
        private System.Windows.Forms.Button ms;
        private System.Windows.Forms.Button m;
        private System.Windows.Forms.TextBox mAns;
    }
}

